let cartTotal = 0;
let itemCount = 0;
const cartItems = {};  // Track added items by their ID

function toggleCartItem(itemId, price) {
    const button = document.getElementById(`btn-${itemId}`);
    
    if (cartItems[itemId]) {
        // Item is already in the cart; remove it
        cartTotal -= price;
        itemCount -= 1;
        delete cartItems[itemId];
        button.innerText = "Add to Cart";
    } else {
        // Item is not in the cart; add it
        cartTotal += price;
        itemCount += 1;
        cartItems[itemId] = true;
        button.innerText = "Remove from Cart";
    }

    // Update the cart display
    document.getElementById('cart-total').innerText = cartTotal.toFixed(2);
    document.getElementById('item-count').innerText = itemCount;
}

function checkout() {
    if (itemCount === 0) {
        alert("Your cart is empty!");
        return;
    }

    // Show the total amount and item count in an alert
    alert(`Thank you for your purchase! You bought ${itemCount} items for a total of $${cartTotal.toFixed(2)}.`);

    // Reset the cart for the next transaction
    cartTotal = 0;
    itemCount = 0;
    for (const itemId in cartItems) {
        document.getElementById(`btn-${itemId}`).innerText = "Add to Cart";
    }
    Object.keys(cartItems).forEach(id => delete cartItems[id]);
    document.getElementById('cart-total').innerText = "0.00";
    document.getElementById('item-count').innerText = "0";
}


